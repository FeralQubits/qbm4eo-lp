# qbm4eo

## Installation
`pip install .`

## Downloading models

`python -m qbm4eo.cli download https://drive.google.com/file/d/1B8MXfueA4zEBaDpDgB8JWsH2A1xPtqc8/view?usp=sharing --destination ./mnist_model`

## Launch examples

`python -m qbm4eo.cli predict --model-path mnist_model data_mnist.npy`

