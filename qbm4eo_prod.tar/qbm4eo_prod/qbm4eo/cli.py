import argparse
import tarfile
from pathlib import Path

import numpy as np
import torch

from qbm4eo.pipeline import Pipeline
from qbm4eo.web import download_file


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(required=True)

    download_parser = subparsers.add_parser("download")
    predict_parser = subparsers.add_parser("predict")

    download_parser.add_argument("model_url", help="URL of model to download model's TAR file")
    download_parser.add_argument(
        "--destination",
        help="Directory where the archive should be extracted. Will be created if necessary.",
        default=".",
    )
    download_parser.set_defaults(func=download_action)

    predict_parser.add_argument("data_path", help="path to the data")
    predict_parser.add_argument("--model-path", default=".", help="path with model files")
    predict_parser.set_defaults(func=predict_action)

    args = parser.parse_args()
    args.func(args)


def download_action(args):
    destination = Path(args.destination)
    destination.mkdir(exist_ok=True)
    archive_path = download_file(args.model_url, destination)
    with tarfile.open(archive_path) as tar:
        tar.extractall(destination)


def predict_action(args):
    data = torch.from_numpy(np.load(args.data_path))
    pipeline = Pipeline.load(args.model_path)
    result = pipeline.predict(data)
    np.save("output.npy", result.detach().numpy())


if __name__ == "__main__":
    main()
