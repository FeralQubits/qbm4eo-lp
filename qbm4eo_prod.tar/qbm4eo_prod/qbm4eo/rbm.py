import numpy as np
from scipy.special import expit

INITIAL_COEF_SCALE = 0.1


class RBM:
    def __init__(self, num_visible: int, num_hidden: int, rng=None):
        self.num_visible = num_visible
        self.num_hidden = num_hidden
        self.rng = rng if rng is not None else np.random.default_rng()

        self.weights = (
            self.rng.normal(size=(self.num_visible, self.num_hidden)) * INITIAL_COEF_SCALE
        )
        self.v_bias = self.rng.normal(size=self.num_visible) * INITIAL_COEF_SCALE
        self.h_bias = self.rng.normal(size=self.num_hidden) * INITIAL_COEF_SCALE

    def h_probs_given_v(self, v_batch):
        return expit(self.h_bias + v_batch @ self.weights)

    def sample_h_given_v(self, v_batch):
        probs = self.h_probs_given_v(v_batch)
        return (self.rng.random(probs.shape) < probs).astype(float)

    def v_probs_given_h(self, h_batch):
        return expit(self.v_bias + h_batch @ self.weights.T)

    def sample_v_given_h(self, h_batch):
        probs = self.v_probs_given_h(h_batch)
        return (self.rng.random(probs.shape) < probs).astype(float)

    def reconstruct(self, v_batch):
        return self.v_probs_given_h(self.h_probs_given_v(v_batch))

    def save(self, file):
        np.savez(file, v_bias=self.v_bias, h_bias=self.h_bias, weights=self.weights)

    @classmethod
    def load(cls, file):
        data = np.load(file)
        weights, v_bias, h_bias = data["weights"], data["v_bias"], data["h_bias"]
        rbm = cls(num_visible=len(v_bias), num_hidden=len(h_bias))
        rbm.weights = weights
        rbm.v_bias = v_bias
        rbm.h_bias = h_bias
        return rbm
