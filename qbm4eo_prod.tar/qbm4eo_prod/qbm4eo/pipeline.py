from pathlib import Path

import torch

from qbm4eo.classifier import Classifier
from qbm4eo.lbae import LBAE
from qbm4eo.rbm import RBM


def encoded_dataloader(data_loader, encoder):
    while True:
        for batch_idx, (data, target) in enumerate(data_loader):
            yield encoder(data)[0], target


class Pipeline:
    def __init__(self, auto_encoder, rbm, classifier):
        self.auto_encoder = auto_encoder
        self.rbm = rbm
        self.classifier = classifier

    def predict(self, data_loader):
        return self.classifier(
            torch.from_numpy(
                self.rbm.h_probs_given_v(self.auto_encoder.encoder(data_loader)[0].detach().numpy())
            ).float()
        )

    @classmethod
    def load(cls, path):
        path = Path(path)
        auto_encoder = LBAE.load_from_checkpoint(str(path / "lbae.ckpt"))
        rbm = RBM.load(path / "rbm.npz")
        classifier = Classifier.load_from_checkpoint(
            str(path / "classifier.ckpt"), encoder=auto_encoder.encoder, rbm=rbm
        )
        return cls(auto_encoder, rbm, classifier)
